import { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import Work from './components/Work';
import About from './components/About';
import Process from './components/Process';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CustomCursor from './components/CustomCursor';
import Testimonials from './components/Testimonials';
import ParallaxImage from './components/ParallaxImage';
import Press from './components/Press';
import Loader from './components/Loader';

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { scrollYProgress } = useScroll();
  const progressWidth = useTransform(scrollYProgress, [0, 1], ['0%', '100%']);

  return (
    <div className="relative cursor-none">
      {/* Loader */}
      <Loader onComplete={() => setIsLoading(false)} />

      {/* Scroll progress bar */}
      {!isLoading && (
        <motion.div
          style={{ width: progressWidth }}
          className="fixed top-0 left-0 h-[2px] bg-warm z-[100]"
        />
      )}

      {/* Noise texture overlay */}
      <div className="noise-overlay" />

      {/* Custom Cursor */}
      {!isLoading && <CustomCursor />}

      {/* Navigation */}
      {!isLoading && <Navigation />}

      {/* Main Content */}
      {!isLoading && (
        <main>
          <Hero />
          <Marquee />
          <ParallaxImage />
          <Work />
          <About />
          <Process />
          <Testimonials />
          <Services />
          <Contact />
          <Press />
        </main>
      )}

      {/* Footer */}
      {!isLoading && <Footer />}

      {/* Back to top button */}
      {!isLoading && <BackToTop />}
    </div>
  );
}

function BackToTop() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPercent = window.scrollY / (document.documentElement.scrollHeight - window.innerHeight);
      setIsVisible(scrollPercent > 0.2);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
      transition={{ duration: 0.3 }}
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className="fixed bottom-8 right-8 w-12 h-12 rounded-full bg-dark text-light flex items-center justify-center z-50 hover:bg-warm hover:text-darker transition-colors duration-300 shadow-lg"
      aria-label="Back to top"
    >
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M8 12V4M4 7l4-4 4 4" />
      </svg>
    </motion.button>
  );
}

export default App;
