import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { ArrowUpRight, Mail, MapPin, Phone } from 'lucide-react';

export default function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [formState, setFormState] = useState({ name: '', email: '', message: '', type: 'architecture' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="py-32 px-6 md:px-12 bg-darker text-light" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Left */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <span className="text-sm tracking-[0.3em] uppercase text-warm">Get in Touch</span>
              <h2 className="font-serif text-4xl md:text-6xl mt-4 leading-tight">
                Let's create<br />
                <span className="italic text-warm">something</span><br />
                together.
              </h2>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mt-12 space-y-6"
            >
              <p className="text-light/50 text-lg leading-relaxed">
                Whether you have a project in mind or simply want to explore possibilities, 
                we'd love to hear from you. Every great collaboration starts with a conversation.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-12 space-y-4"
            >
              <div className="flex items-center gap-4 text-light/60">
                <Mail size={18} className="text-warm" />
                <span>hello@studiokael.com</span>
              </div>
              <div className="flex items-center gap-4 text-light/60">
                <Phone size={18} className="text-warm" />
                <span>+45 32 14 56 78</span>
              </div>
              <div className="flex items-center gap-4 text-light/60">
                <MapPin size={18} className="text-warm" />
                <span>Nørrebrogade 42, Copenhagen</span>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-12 flex gap-4"
            >
              {['Instagram', 'LinkedIn', 'Behance'].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="group flex items-center gap-1 text-sm text-light/40 hover:text-warm transition-colors"
                >
                  {social}
                  <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              ))}
            </motion.div>
          </div>

          {/* Right - Form */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <form onSubmit={handleSubmit} className="space-y-8">
              <div>
                <label className="text-xs tracking-[0.2em] uppercase text-light/40 mb-3 block">
                  Project Type
                </label>
                <div className="flex gap-3">
                  {['architecture', 'product', 'interior'].map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setFormState({ ...formState, type })}
                      className={`px-4 py-2 text-sm rounded-full border transition-all duration-300 ${
                        formState.type === type
                          ? 'border-warm text-warm bg-warm/10'
                          : 'border-light/10 text-light/40 hover:border-light/30'
                      }`}
                    >
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-xs tracking-[0.2em] uppercase text-light/40 mb-3 block">
                    Name
                  </label>
                  <input
                    type="text"
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    className="w-full bg-transparent border-b border-light/10 py-3 text-light focus:border-warm focus:outline-none transition-colors"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="text-xs tracking-[0.2em] uppercase text-light/40 mb-3 block">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formState.email}
                    onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                    className="w-full bg-transparent border-b border-light/10 py-3 text-light focus:border-warm focus:outline-none transition-colors"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs tracking-[0.2em] uppercase text-light/40 mb-3 block">
                  Message
                </label>
                <textarea
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  rows={4}
                  className="w-full bg-transparent border-b border-light/10 py-3 text-light focus:border-warm focus:outline-none transition-colors resize-none"
                  placeholder="Tell us about your project..."
                />
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-4 bg-warm text-darker text-sm tracking-[0.2em] uppercase font-medium rounded-sm hover:bg-warm-light transition-colors duration-300"
              >
                {isSubmitted ? '✓ Message Sent' : 'Send Message'}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
