import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const press = [
  'Dezeen',
  'ArchDaily',
  'Wallpaper*',
  'Dwell',
  'Monocle',
  'Frame',
];

export default function Press() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <section ref={ref} className="py-20 px-6 md:px-12 border-b border-dark/5">
      <div className="max-w-7xl mx-auto">
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center text-xs tracking-[0.3em] uppercase text-mid mb-12"
        >
          Featured In
        </motion.p>

        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
          {press.map((name, i) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="font-serif text-xl md:text-2xl text-dark/20 hover:text-dark/60 transition-colors duration-300 cursor-default"
            >
              {name}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
