import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const stats = [
  { number: '12+', label: 'Years Experience' },
  { number: '80+', label: 'Projects Completed' },
  { number: '15', label: 'Design Awards' },
  { number: '6', label: 'Countries' },
];

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-32 px-6 md:px-12 bg-dark text-light" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Left Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <span className="text-sm tracking-[0.3em] uppercase text-warm">About</span>
              <h2 className="font-serif text-4xl md:text-6xl mt-4 leading-tight">
                Design is the
                <br />
                <span className="italic text-warm">silent ambassador</span>
                <br />
                of your brand.
              </h2>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mt-12 space-y-6"
            >
              <p className="text-light/60 text-lg leading-relaxed">
                I'm Kael Morrison — an architect and product designer based in Copenhagen. 
                My practice sits at the intersection of spatial design and object-making, 
                where I explore how the things we build and the objects we create shape 
                our daily rituals.
              </p>
              <p className="text-light/60 text-lg leading-relaxed">
                Every project begins with a question: how can this space or object 
                elevate the human experience? From private residences to furniture collections, 
                I approach each commission with the same rigor — listening to context, 
                respecting materials, and pursuing clarity.
              </p>
            </motion.div>
          </div>

          {/* Right Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative"
            >
              <div className="aspect-[3/4] overflow-hidden rounded-sm">
                <img
                  src="https://image.qwenlm.ai/generated-images/5e37630f-af85-4ab4-8dd8-18ab9cc22e27/_result.png"
                  alt="Studio Kael workspace"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 border border-warm/30" />
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-warm/10" />
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="grid grid-cols-2 gap-8 mt-16"
            >
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.6 + i * 0.1 }}
                >
                  <span className="font-serif text-4xl md:text-5xl text-warm">{stat.number}</span>
                  <p className="text-light/50 text-sm mt-2">{stat.label}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
