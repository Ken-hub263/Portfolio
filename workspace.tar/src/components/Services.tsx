import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { Building2, Lamp, PenTool, Layers } from 'lucide-react';

const services = [
  {
    icon: Building2,
    title: 'Architecture',
    description: 'From concept to completion — residential, commercial, and cultural spaces designed with intention and precision.',
    details: ['Residential Design', 'Commercial Spaces', 'Renovation', 'Urban Planning'],
  },
  {
    icon: Lamp,
    title: 'Product Design',
    description: 'Objects that balance aesthetic beauty with functional purpose, crafted for how people actually live.',
    details: ['Furniture', 'Lighting', 'Home Accessories', 'Limited Editions'],
  },
  {
    icon: PenTool,
    title: 'Interior Design',
    description: 'Curated interiors that tell a story — material palettes, spatial flow, and atmosphere in harmony.',
    details: ['Space Planning', 'Material Selection', 'Custom Millwork', 'Art Curation'],
  },
  {
    icon: Layers,
    title: 'Design Consulting',
    description: 'Strategic design guidance for brands, developers, and individuals seeking clarity in their vision.',
    details: ['Brand Environments', 'Design Strategy', 'Workshops', 'Feasibility Studies'],
  },
];

export default function Services() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [activeService, setActiveService] = useState<number | null>(null);

  return (
    <section id="services" className="py-32 px-6 md:px-12" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <span className="text-sm tracking-[0.3em] uppercase text-mid">What We Do</span>
          <h2 className="font-serif text-4xl md:text-6xl text-dark mt-4">
            Services &<br />
            <span className="italic text-warm">Expertise</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-t border-dark/10">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isActive = activeService === index;

            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`border-b border-r-0 md:border-r md:odd:border-r-dark/10 p-8 md:p-12 cursor-pointer transition-all duration-500 group ${
                  index % 2 === 1 ? 'md:border-r' : ''
                } ${isActive ? 'bg-dark text-light' : 'hover:bg-dark/5'}`}
                onMouseEnter={() => setActiveService(index)}
                onMouseLeave={() => setActiveService(null)}
              >
                <div className="flex items-start gap-6">
                  <motion.div
                    animate={{ rotate: isActive ? 90 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Icon
                      size={28}
                      className={`transition-colors duration-300 ${
                        isActive ? 'text-warm' : 'text-mid group-hover:text-dark'
                      }`}
                      strokeWidth={1.5}
                    />
                  </motion.div>

                  <div className="flex-1">
                    <h3 className={`font-serif text-2xl md:text-3xl transition-colors duration-300 ${
                      isActive ? 'text-light' : 'text-dark'
                    }`}>
                      {service.title}
                    </h3>
                    <p className={`mt-3 text-sm leading-relaxed transition-colors duration-300 ${
                      isActive ? 'text-light/60' : 'text-mid'
                    }`}>
                      {service.description}
                    </p>

                    <motion.div
                      initial={false}
                      animate={{ height: isActive ? 'auto' : 0, opacity: isActive ? 1 : 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="flex flex-wrap gap-2 mt-6">
                        {service.details.map((detail) => (
                          <span
                            key={detail}
                            className={`text-xs px-3 py-1.5 rounded-full border transition-colors duration-300 ${
                              isActive
                                ? 'border-warm/30 text-warm'
                                : 'border-dark/10 text-mid'
                            }`}
                          >
                            {detail}
                          </span>
                        ))}
                      </div>
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
