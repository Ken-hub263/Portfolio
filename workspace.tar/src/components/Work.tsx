import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';

const projects = [
  {
    id: 1,
    title: 'The Glass Pavilion',
    category: 'Architecture',
    year: '2024',
    description: 'A residential retreat dissolving boundaries between interior and landscape.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
    color: '#e8e4df',
  },
  {
    id: 2,
    title: 'Monolith Chair',
    category: 'Product Design',
    year: '2024',
    description: 'A sculptural seating piece carved from a single block of engineered stone.',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80',
    color: '#d4cfc7',
  },
  {
    id: 3,
    title: 'Horizon Tower',
    category: 'Architecture',
    year: '2023',
    description: 'Mixed-use tower redefining the urban skyline with cantilevered volumes.',
    image: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=800&q=80',
    color: '#ddd8d0',
  },
  {
    id: 4,
    title: 'Arc Lamp Series',
    category: 'Product Design',
    year: '2023',
    description: 'Minimalist lighting collection exploring tension between weight and lightness.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    color: '#e2ddd5',
  },
  {
    id: 5,
    title: 'Courtyard House',
    category: 'Architecture',
    year: '2023',
    description: 'A private residence organized around a central void, drawing light inward.',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    color: '#d9d4cc',
  },
  {
    id: 6,
    title: 'Vessel Collection',
    category: 'Product Design',
    year: '2022',
    description: 'Ceramic vessels exploring the dialogue between mass and negative space.',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&q=80',
    color: '#e5e0d8',
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
      className={`project-card group cursor-pointer ${
        index % 3 === 0 ? 'md:col-span-2' : 'md:col-span-1'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden rounded-sm" style={{ backgroundColor: project.color }}>
        <motion.div
          animate={{ scale: isHovered ? 1.05 : 1 }}
          transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="aspect-[4/3] overflow-hidden"
        >
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover"
          />
        </motion.div>

        {/* Overlay info */}
        <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-8 z-10">
          <motion.div
            animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 20 }}
            transition={{ duration: 0.4 }}
            className="project-info"
          >
            <p className="text-white/70 text-sm mb-1">{project.description}</p>
          </motion.div>
        </div>
      </div>

      <div className="mt-4 flex items-start justify-between">
        <div>
          <h3 className="font-serif text-xl md:text-2xl text-dark group-hover:text-warm transition-colors duration-300">
            {project.title}
          </h3>
          <p className="text-mid text-sm mt-1">{project.category}</p>
        </div>
        <span className="text-mid text-sm">{project.year}</span>
      </div>
    </motion.div>
  );
}

export default function Work() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="work" className="py-32 px-6 md:px-12" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <span className="text-sm tracking-[0.3em] uppercase text-mid">Selected Work</span>
          <h2 className="font-serif text-4xl md:text-6xl text-dark mt-4">
            Featured<br />
            <span className="italic text-warm">Projects</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
