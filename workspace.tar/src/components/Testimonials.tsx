import { motion, useInView } from 'framer-motion';
import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    quote: "Kael's ability to translate abstract ideas into tangible, beautiful spaces is unmatched. Our home feels like a living sculpture.",
    author: 'Maria Lindström',
    role: 'Private Client, Stockholm',
  },
  {
    quote: "The chair collection redefined how we think about our product line. Every piece carries a quiet confidence that speaks volumes.",
    author: 'Thomas Voss',
    role: 'Creative Director, Möbel Co.',
  },
  {
    quote: "Working with Studio Kael was a masterclass in restraint and intention. Nothing is superfluous, everything is considered.",
    author: 'Yuki Tanaka',
    role: 'Gallery Owner, Tokyo',
  },
];

export default function Testimonials() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="py-32 px-6 md:px-12 bg-light overflow-hidden" ref={ref}>
      <div className="max-w-5xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <Quote size={40} className="mx-auto text-warm/30 mb-8" strokeWidth={1} />
        </motion.div>

        <div className="relative min-h-[200px]">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{
                opacity: current === index ? 1 : 0,
                y: current === index ? 0 : 20,
                position: current === index ? 'relative' as const : 'absolute' as const,
              }}
              transition={{ duration: 0.5 }}
              className={current === index ? '' : 'top-0 left-0 right-0 pointer-events-none'}
            >
              <blockquote className="font-serif text-2xl md:text-4xl text-dark leading-relaxed italic">
                "{testimonial.quote}"
              </blockquote>
              <div className="mt-8">
                <p className="text-dark font-medium">{testimonial.author}</p>
                <p className="text-mid text-sm mt-1">{testimonial.role}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex items-center justify-center gap-6 mt-12"
        >
          <button
            onClick={prev}
            className="w-12 h-12 rounded-full border border-dark/10 flex items-center justify-center hover:border-warm hover:text-warm transition-all duration-300 text-dark/40"
          >
            <ChevronLeft size={18} />
          </button>

          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  current === i ? 'bg-warm w-6' : 'bg-dark/10'
                }`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="w-12 h-12 rounded-full border border-dark/10 flex items-center justify-center hover:border-warm hover:text-warm transition-all duration-300 text-dark/40"
          >
            <ChevronRight size={18} />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
