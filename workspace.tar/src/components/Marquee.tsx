import { motion } from 'framer-motion';

export default function Marquee() {
  const items = [
    'Architecture',
    'Product Design',
    'Interior Design',
    'Spatial Experience',
    'Material Research',
    'Sustainable Design',
  ];

  return (
    <div className="py-8 overflow-hidden border-y border-dark/5 bg-light">
      <motion.div
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        className="flex gap-12 whitespace-nowrap"
      >
        {[...items, ...items].map((item, i) => (
          <span key={i} className="flex items-center gap-12">
            <span className="font-serif text-2xl md:text-4xl text-dark/10 italic">{item}</span>
            <span className="w-2 h-2 rounded-full bg-warm/30" />
          </span>
        ))}
      </motion.div>
    </div>
  );
}
