import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const steps = [
  {
    number: '01',
    title: 'Listen',
    description: 'Every project starts with deep listening — understanding the site, the client, and the unseen constraints that shape great design.',
  },
  {
    number: '02',
    title: 'Explore',
    description: 'We iterate through models, sketches, and prototypes, testing ideas against reality until the right solution reveals itself.',
  },
  {
    number: '03',
    title: 'Refine',
    description: 'Details are distilled. Materials are selected. Every joint, every proportion is considered until nothing more can be removed.',
  },
  {
    number: '04',
    title: 'Realize',
    description: 'From drawing to built form — we oversee fabrication and construction with the same care we bring to the first sketch.',
  },
];

export default function Process() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-32 px-6 md:px-12 bg-light" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-20 text-center"
        >
          <span className="text-sm tracking-[0.3em] uppercase text-mid">Our Process</span>
          <h2 className="font-serif text-4xl md:text-6xl text-dark mt-4">
            How we <span className="italic text-warm">work</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-0 relative">
          {/* Connecting line */}
          <div className="hidden md:block absolute top-12 left-[12.5%] right-[12.5%] h-px bg-dark/10">
            <motion.div
              initial={{ scaleX: 0 }}
              animate={isInView ? { scaleX: 1 } : {}}
              transition={{ duration: 1.5, delay: 0.5 }}
              className="h-full bg-warm/40 origin-left"
            />
          </div>

          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.15 }}
              className="relative text-center md:px-6"
            >
              <div className="w-24 h-24 mx-auto mb-8 rounded-full border border-dark/10 flex items-center justify-center relative bg-light">
                <span className="font-serif text-2xl text-warm">{step.number}</span>
              </div>
              <h3 className="font-serif text-xl text-dark mb-3">{step.title}</h3>
              <p className="text-mid text-sm leading-relaxed">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
