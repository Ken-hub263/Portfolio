import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

export default function ParallaxImage() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['-10%', '10%']);

  return (
    <section ref={ref} className="relative h-[60vh] md:h-[80vh] overflow-hidden">
      <motion.div style={{ y }} className="absolute inset-0 -top-[10%] -bottom-[10%]">
        <img
          src="https://image.qwenlm.ai/generated-images/85141f44-579d-4312-b5df-fd7729e37610/_result.png"
          alt="Interior architecture"
          className="w-full h-full object-cover"
        />
      </motion.div>
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-dark/30" />
      
      {/* Text overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="font-serif text-3xl md:text-5xl lg:text-6xl text-white italic leading-tight">
            "Less is more,<br />but less has to be<br />
            <span className="text-warm">exactly right.</span>"
          </p>
        </motion.div>
      </div>
    </section>
  );
}
