import { motion } from 'framer-motion';

export default function Footer() {
  return (
    <footer className="py-12 px-6 md:px-12 bg-darker border-t border-light/5">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="font-serif text-xl text-light/80"
          >
            Studio<span className="text-warm">.</span>Kael
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-light/30 text-sm"
          >
            © 2024 Studio Kael. All rights reserved.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex items-center gap-6"
          >
            <a href="#" className="text-light/30 text-sm hover:text-warm transition-colors">Privacy</a>
            <a href="#" className="text-light/30 text-sm hover:text-warm transition-colors">Terms</a>
            <a href="#" className="text-light/30 text-sm hover:text-warm transition-colors">Sitemap</a>
          </motion.div>
        </div>
      </div>
    </footer>
  );
}
